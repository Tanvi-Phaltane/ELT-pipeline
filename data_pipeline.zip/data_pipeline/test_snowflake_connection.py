from snowflake import connector

ctx = connector.connect(
    user = "TPH",
    password = "Tpk@1992",
    account="rpmeeez-gy76253",
    enable_connnection_diag=True
)

print("connected")